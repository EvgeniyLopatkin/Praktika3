#include <8051.h>
void main()
{
	unsigned int i;
	unsigned int j;
	unsigned char *str="";
	unsigned char *spaces=" ";

	char *str2="2nd lines";
	int SIZE = 9;
	int s=0;


	P0 = 0x38;//
	P2 = 0x1;
	P2 = 0x0;
	P0 = 0x80;
	P2 = 0x1;
	P2 = 0x0;
	for(i=0;i<0;i++) //Output on LCD 1st string
	{
		//P0 = str[i];
		//P2 = 0x2;
		//P2 = 0x3;
	}


	while(1)
	{
		P0 = 0xC0;
		P2 = 0x1;
		P2 = 0x0;
		for(i=0;i<SIZE;i++) //2nd string
		{
			if(i==0){for(j=0;j<SIZE-9;j++){P0 = spaces[0]; P2 = 0x2; /*P2 = 0x3;*/}}
			P0 = str2[i];
			P2 = 0x2;
			//P2 = 0x3;
		}
		SIZE+=1;
	}
	
	while(1);
}